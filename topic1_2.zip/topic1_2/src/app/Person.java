package app;

public class Person {
	private String name;
	private int age;
	private float weight; //* in inches
	
	/**
	 * 
	 * @param name
	 * @param age
	 * @param weight
	 */
	public Person(String name, int age , float weight) 
	{
		super();
		this.name = name;
		this.age = age;
		this.weight = weight;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getAge() {
		return age;
	}
	
	/**
	 * 
	 * @return
	 */
	public float getWeight() {
		return weight;
	}
	
	/**
	 * 
	 */
	public void walk()
	{
		System.out.println("I am in walk()");
	}
	
	/**
	 * 
	 * @param distance
	 * @return
	 */
	public float run(float distance)
	{
		System.out.println("I am in run()");
		return 0;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person = new Person("Roberto", 25, (float) 165.02);
		System.out.println("My name is " + person.getName());
		person.walk();
		person.run(10);

	}

}
