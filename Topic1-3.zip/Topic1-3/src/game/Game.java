package game;
import java.util.Scanner;

public class Game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a scanner for user input
		Scanner scan = new Scanner(System.in);
		
		// Create a question for the air pressure for the tires from the user
		System.out.println("What is the air pressure on your tires?");
		int tirePressure = scan.nextInt(); 
		
		// Create a question to see if the car has a engine
		System.out.println("Does the car have an engine? (True/False)");
		boolean engine = scan.nextBoolean();
		
		// Create an array for all four tires
		Car userCar = new Car(tirePressure, engine);
		
		//call the startCar method in Car
		userCar.startCar();
		 
		//create a variable for an action from the user
		String action = scan.next();
		
		//Send the car action to newCarAction in Car class
		userCar.newCarAction(action); 
		
		//call the carAction method in car
		userCar.carAction();
		
		scan.close();
	}

}
