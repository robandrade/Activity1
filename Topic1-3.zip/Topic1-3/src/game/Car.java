package game;

public class Car {
	// create variables private
	private int tirePressure;
	private boolean carEngine;
	
	// create constructor for Car to get user input from Game class
	public Car(int userTirePress, boolean userEngine) {
		// bring in the parameters to a variable
		this.tirePressure = userTirePress;
		this.carEngine = userEngine;
	}

	
	// method for starting the car
	void startCar() {
		
		// object to send tirePressure to Tire class
		Tire userTires = new Tire(tirePressure);
		
		// check if the car has an engine with an if statement, this is for false
		if(carEngine == false) {
			System.out.println("Car does not have an engine");
			System.out.println("\nGame Over");
					
		}
		// what to do if the car has an engine
		else{
			System.out.println("\nStarting Car! \n");
			
			//if statement to see if the car's tire pressure is good
			if (userTires.getTireCondition() == false) {
				System.out.println("There isn't enough air pressure in the tires! \n\n");
				System.out.println("\nGame Over");
			}
			
			//if the tire's pressure is good, make it drive
			else {
				int carMPH = 0;
				
				// for loop to state the cars speed
				for(int i = 0; i <= 29; i++) {
				carMPH++;
				
				//create message to see cars speed
				System.out.println("Car is going " + carMPH + " MPH");
				}
				
				// ask if the user would like to stop the car in a true or false question
				System.out.println("Would you like to stop the car? (True/False)");
			}
		}
		
	}
	
	// create new private variables for new action and new speed
	private String newAction;
	private int newMph = 30;
	
	//create a method to receive the new car action
	void newCarAction(String action) {
		this.newAction = action;
	}
	
	// create method for the new action
	void carAction() {
		
		// an if statement to see the users action, if true stop the car
		if (newAction.equals("True")) {
			System.out.println("Car has been stopped!\nCar is at " + 0 + " MPH");
		}
		
		// if users action is false restart the car
		else if (newAction.equals("False")){
			System.out.println("Car has restarted!\n");
			
			// for loop to make the car go to 60mph
			for (int j = 30; j <= 59; j++) {
				newMph++;
				
				// create message to see the cars speed
				System.out.println("Car is going " + newMph + " MPH");
			}
			
			// create messages to send to user when finished
			System.out.println("\nCar has stopped\n");
			System.out.println("\nGameOver");
		}
	}

}
