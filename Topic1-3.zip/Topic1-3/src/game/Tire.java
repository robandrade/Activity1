package game;

public class Tire {
	
	// create private variables for tire pressure
	  private int tirePressureGauge;
	  private boolean tireReady;
	 
	  // a constructor to receive the tire pressure and send to setter
	  Tire(int Pressure) {
		  this.setTireCondition(Pressure);
	  }
	  
	  // create setter to set tirePressure
	  public void setTireCondition(int Pressure) {
		  this.tirePressureGauge = Pressure;
		  
		  // an if statement to see if the tire pressure is less or greater than 31
		  if (tirePressureGauge > 31) {
			  this.tireReady = true;
		  }
		  else {
			  this.tireReady = false;
		  }
		    
	  }
	  
	  // create a getter to return the boolean of tireReady to the Car
	  public boolean getTireCondition() {
		  return tireReady;
	  }
}


